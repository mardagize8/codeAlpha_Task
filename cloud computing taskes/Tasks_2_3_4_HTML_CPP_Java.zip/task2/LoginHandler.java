import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import java.sql.*;

public class LoginHandler {
  static String KEY = "0123456789abcdef0123456789abcdef";
  static String IV = "0123456789abcdef";

  public static String encrypt(String s) throws Exception {
    Cipher c = Cipher.getInstance("AES/CBC/PKCS5Padding");
    c.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(KEY.getBytes(), "AES"),
           new javax.crypto.spec.IvParameterSpec(IV.getBytes()));
    return Base64.getEncoder().encodeToString(c.doFinal(s.getBytes()));
  }

  public static boolean check(String user, String pass, String cap) throws Exception {
    if(!"CAP2025".equals(cap)) return false;
    String enc = encrypt(pass);
    try (Connection con = DriverManager.getConnection(...);
         PreparedStatement st = con.prepareStatement(
           "SELECT * FROM users WHERE username=? AND pass_enc=?")) {
       st.setString(1, user); st.setString(2, enc);
       try (ResultSet rs = st.executeQuery()) {
         return rs.next();
       }
    }
  }
}