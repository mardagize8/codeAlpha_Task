#include <soci/soci.h>
#include <iostream>

int main() {
  soci::session sql(soci::postgres, "dbname=mydb user=dbuser");
  std::string user, pass;
  std::cout<<"Enter user: "; std::cin>>user;
  std::cout<<"Enter pass: "; std::cin>>pass;

  soci::indicator ind;
  int count;
  sql << "SELECT COUNT(*) FROM users WHERE username=:u AND password=:p",
       soci::use(user), soci::use(pass), soci::into(count, ind);

  if(count == 1) std::cout<<"Login OK\n";
  else std::cout<<"Invalid\n";
}