#include <iostream>
#include <mutex>
#include <vector>

struct Ticket { int id; std::string user, route; };

int main(){
  std::vector<Ticket> db;
  std::mutex m;
  int id=0;

  auto book = [&](std::string u, std::string r){
    std::lock_guard<std::mutex> lk(m);
    db.push_back({++id,u,r});
    std::cout<<"Ticket "<<id<<" by "<<u<<" on "<<r<<"\n";
  };

  book("Alice","A→B");
  book("Bob","B→C");
}