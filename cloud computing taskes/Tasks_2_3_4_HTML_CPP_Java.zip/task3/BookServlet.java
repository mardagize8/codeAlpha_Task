import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.concurrent.atomic.AtomicInteger;

@WebServlet("/book")
public class BookServlet extends HttpServlet {
  static AtomicInteger idGen = new AtomicInteger();
  public void doPost(HttpServletRequest rq, HttpServletResponse rs)
      throws IOException {
    String user = rq.getParameter("name");
    String route = rq.getParameter("route");
    int id = idGen.incrementAndGet();
    rs.setContentType("application/json");
    rs.getWriter().write("{\"ticketId\":" + id + "}");
  }
}