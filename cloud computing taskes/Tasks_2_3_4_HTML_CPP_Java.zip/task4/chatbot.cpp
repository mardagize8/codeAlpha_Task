#include <iostream>
#include <map>
using namespace std;

int main(){
  map<string,string> kb = {
    {"hi","Hello!"},
    {"help","How can I assist?"}
  };
  string msg;
  while(getline(cin,msg)){
    cout << (kb.count(msg)? kb[msg]:"I don't understand") << endl;
  }
}