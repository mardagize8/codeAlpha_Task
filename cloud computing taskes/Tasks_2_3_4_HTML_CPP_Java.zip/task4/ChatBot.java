import java.util.Scanner;

public class ChatBot {
  public static void main(String[] args){
    Scanner sc = new Scanner(System.in);
    while(true){
      String msg = sc.nextLine().toLowerCase();
      if(msg.contains("hello")) System.out.println("Hi there!");
      else if(msg.contains("price")) System.out.println("What are you looking to buy?");
      else System.out.println("Sorry, can you repeat?");
    }
  }
}