
import java.io.*;
import java.util.*;

public class RedundancyRemover {
    static Set<String> loadDatabase(String filename) throws IOException {
        Set<String> data = new HashSet<>();
        BufferedReader reader = new BufferedReader(new FileReader(filename));
        String line;
        while ((line = reader.readLine()) != null) {
            data.add(line.trim());
        }
        reader.close();
        return data;
    }

    static void appendIfUnique(String filename, String entry) throws IOException {
        Set<String> existing = loadDatabase(filename);
        if (!existing.contains(entry)) {
            FileWriter writer = new FileWriter(filename, true);
            writer.write(entry + "\n");
            writer.close();
            System.out.println("Data appended.");
        } else {
            System.out.println("Duplicate data detected. Not added.");
        }
    }

    public static void main(String[] args) throws IOException {
        String dbFile = "database.txt";
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter new data: ");
        String newEntry = scanner.nextLine();

        appendIfUnique(dbFile, newEntry);
    }
}
