
#include <iostream>
#include <fstream>
#include <set>
#include <string>

using namespace std;

set<string> loadDatabase(const string& filename) {
    set<string> data;
    string line;
    ifstream file(filename);
    while (getline(file, line)) {
        data.insert(line);
    }
    file.close();
    return data;
}

void appendIfUnique(const string& filename, const string& entry) {
    set<string> existing = loadDatabase(filename);
    if (existing.find(entry) == existing.end()) {
        ofstream file(filename, ios::app);
        file << entry << endl;
        cout << "Data appended.\n";
    } else {
        cout << "Duplicate data detected. Not added.\n";
    }
}

int main() {
    string dbFile = "database.txt";
    string newEntry;

    cout << "Enter new data: ";
    getline(cin, newEntry);

    appendIfUnique(dbFile, newEntry);
    return 0;
}
