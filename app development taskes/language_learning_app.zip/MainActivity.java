
// MainActivity.java
public class MainActivity extends AppCompatActivity {
    TextView wordText;
    Button showButton, quizButton;
    String[] english = {"hello", "thank you"};
    String[] spanish = {"hola", "gracias"};
    int current = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        wordText = findViewById(R.id.wordText);
        showButton = findViewById(R.id.showButton);
        quizButton = findViewById(R.id.quizButton);

        showButton.setOnClickListener(v -> {
            wordText.setText(english[current] + " - " + spanish[current]);
            current = (current + 1) % english.length;
        });

        quizButton.setOnClickListener(v -> {
            // Start Quiz Activity (new screen)
        });
    }
}
