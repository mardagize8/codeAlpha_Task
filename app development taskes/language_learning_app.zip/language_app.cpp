
#include <iostream>
#include <vector>
#include <map>
using namespace std;

class LanguageApp {
    map<string, string> vocabulary;
public:
    LanguageApp() {
        vocabulary["hello"] = "hola";
        vocabulary["goodbye"] = "adiós";
        vocabulary["please"] = "por favor";
        vocabulary["thank you"] = "gracias";
    }

    void showFlashcards() {
        cout << "Flashcards:\n";
        for (auto& [eng, foreign] : vocabulary) {
            cout << eng << " - " << foreign << endl;
        }
    }

    void quiz() {
        string answer;
        int score = 0;
        cout << "\nQuiz Time:\n";
        for (auto& [eng, foreign] : vocabulary) {
            cout << "Translate '" << eng << "': ";
            cin >> answer;
            if (answer == foreign) score++;
        }
        cout << "You got " << score << "/" << vocabulary.size() << " correct!\n";
    }
};

int main() {
    LanguageApp app;
    app.showFlashcards();
    app.quiz();
    return 0;
}
