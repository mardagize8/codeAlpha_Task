const quotes = [
  { text: "The best way to predict the future is to invent it.", author: "Alan Kay" },
  { text: "Life is what happens when you're busy making other plans.", author: "John Lennon" },
  { text: "You miss 100% of the shots you don’t take.", author: "Wayne Gretzky" },
  { text: "Be yourself; everyone else is already taken.", author: "Oscar Wilde" },
  { text: "Stay hungry, stay foolish.", author: "Steve Jobs" }
];

function getNewQuote() {
  const random = Math.floor(Math.random() * quotes.length);
  document.getElementById('quote').textContent = quotes[random].text;
  document.getElementById('author').textContent = `— ${quotes[random].author}`;
}

getNewQuote();
