let flashcards = JSON.parse(localStorage.getItem('flashcards')) || [];
let currentIndex = 0;
let showFront = true;

function renderCard() {
  const card = flashcards[currentIndex];
  const cardContent = document.getElementById('card-content');

  if (!card) {
    cardContent.textContent = 'No flashcards available';
    return;
  }

  cardContent.textContent = showFront ? card.question : card.answer;
}

function toggleAnswer() {
  showFront = !showFront;
  renderCard();
}

function nextCard() {
  if (flashcards.length === 0) return;
  currentIndex = (currentIndex + 1) % flashcards.length;
  showFront = true;
  renderCard();
}

function prevCard() {
  if (flashcards.length === 0) return;
  currentIndex = (currentIndex - 1 + flashcards.length) % flashcards.length;
  showFront = true;
  renderCard();
}

function addCard() {
  const question = document.getElementById('question').value.trim();
  const answer = document.getElementById('answer').value.trim();

  if (question && answer) {
    flashcards.push({ question, answer });
    localStorage.setItem('flashcards', JSON.stringify(flashcards));
    currentIndex = flashcards.length - 1;
    showFront = true;
    renderCard();
  }
}

function editCard() {
  const question = document.getElementById('question').value.trim();
  const answer = document.getElementById('answer').value.trim();

  if (flashcards[currentIndex] && question && answer) {
    flashcards[currentIndex] = { question, answer };
    localStorage.setItem('flashcards', JSON.stringify(flashcards));
    showFront = true;
    renderCard();
  }
}

function deleteCard() {
  if (flashcards.length === 0) return;
  flashcards.splice(currentIndex, 1);
  if (currentIndex >= flashcards.length) currentIndex = 0;
  localStorage.setItem('flashcards', JSON.stringify(flashcards));
  showFront = true;
  renderCard();
}

// Initialize
renderCard();