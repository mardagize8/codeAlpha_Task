
#include <iostream>
#include <vector>
using namespace std;

struct Activity {
    string exercise;
    int duration;
    int calories;
};

int main() {
    vector<Activity> log;
    int n;
    cout << "How many activities to log? ";
    cin >> n;

    for (int i = 0; i < n; i++) {
        Activity a;
        cout << "\nActivity #" << (i + 1) << endl;
        cout << "Exercise type: ";
        cin >> a.exercise;
        cout << "Duration (min): ";
        cin >> a.duration;
        cout << "Calories burned: ";
        cin >> a.calories;
        log.push_back(a);
    }

    cout << "\n--- Activity Log ---\n";
    for (const auto& a : log) {
        cout << a.exercise << " - " << a.duration << " min - " << a.calories << " kcal\n";
    }

    return 0;
}
