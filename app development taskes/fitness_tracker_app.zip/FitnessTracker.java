
import java.util.ArrayList;
import java.util.Scanner;

class Activity {
    String exercise;
    int duration;
    int calories;

    public Activity(String e, int d, int c) {
        this.exercise = e;
        this.duration = d;
        this.calories = c;
    }

    public void display() {
        System.out.println(exercise + " - " + duration + " min - " + calories + " kcal");
    }
}

public class FitnessTracker {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ArrayList<Activity> log = new ArrayList<>();

        System.out.print("Enter number of activities: ");
        int n = sc.nextInt();

        for (int i = 0; i < n; i++) {
            System.out.print("\nExercise: ");
            String ex = sc.next();
            System.out.print("Duration (min): ");
            int dur = sc.nextInt();
            System.out.print("Calories: ");
            int cal = sc.nextInt();

            log.add(new Activity(ex, dur, cal));
        }

        System.out.println("\n--- Activity Log ---");
        for (Activity a : log) {
            a.display();
        }
    }
}
