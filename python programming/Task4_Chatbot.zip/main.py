def chatbot():
    print("Start chatting with the bot (type 'bye' to stop):")
    while True:
        user = input("You: ").lower()
        if 'hello' in user:
            print("Bot: Hi!")
        elif 'how are you' in user:
            print("Bot: I'm fine, thanks!")
        elif 'bye' in user:
            print("Bot: Goodbye!")
            break
        else:
            print("Bot: Sorry, I didn't understand that.")

chatbot()