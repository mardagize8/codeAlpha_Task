stock_prices = {"AAPL": 180, "TSLA": 250, "GOOGL": 2800}
portfolio = {}
total = 0

print("Enter stock symbols and quantities (type 'done' to finish):")

while True:
    stock = input("Stock Symbol: ").upper()
    if stock == 'DONE':
        break
    if stock in stock_prices:
        qty = int(input("Quantity: "))
        portfolio[stock] = qty
        total += stock_prices[stock] * qty
    else:
        print("Stock not found!")

print("\nPortfolio Summary:")
for s, q in portfolio.items():
    print(f"{s}: {q} shares at ${stock_prices[s]} each")

print(f"Total Investment: ${total}")