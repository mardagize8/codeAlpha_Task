import java.util.*;

public class AIChatbot {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Map<String, String> responses = new HashMap<>();
        responses.put("hi", "Hello!");
        responses.put("how are you", "I'm a bot, doing great!");
        responses.put("bye", "Goodbye!");

        System.out.println("Chatbot is online. Type something (type 'exit' to quit):");
        while (true) {
            System.out.print("> ");
            String input = scanner.nextLine().toLowerCase();
            if (input.equals("exit")) break;

            String response = responses.getOrDefault(input, "Sorry, I don't understand that.");
            System.out.println(response);
        }
    }
}