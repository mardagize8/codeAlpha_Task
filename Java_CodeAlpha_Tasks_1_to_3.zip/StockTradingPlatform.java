import java.util.*;

class Stock {
    String symbol;
    double price;

    Stock(String symbol, double price) {
        this.symbol = symbol;
        this.price = price;
    }
}

public class StockTradingPlatform {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Map<String, Stock> stocks = new HashMap<>();
        stocks.put("AAPL", new Stock("AAPL", 150.0));
        stocks.put("GOOG", new Stock("GOOG", 2800.0));
        stocks.put("TSLA", new Stock("TSLA", 700.0));

        double balance = 10000.0;
        Map<String, Integer> portfolio = new HashMap<>();

        while (true) {
            System.out.println("\nAvailable Stocks:");
            for (Stock s : stocks.values()) {
                System.out.println(s.symbol + " - $" + s.price);
            }

            System.out.println("Your Balance: $" + balance);
            System.out.print("Enter stock symbol to buy/sell or 'exit': ");
            String input = scanner.nextLine();

            if (input.equalsIgnoreCase("exit")) break;
            if (!stocks.containsKey(input)) {
                System.out.println("Invalid symbol.");
                continue;
            }

            System.out.print("Buy or Sell? ");
            String action = scanner.nextLine();
            System.out.print("Enter quantity: ");
            int qty = Integer.parseInt(scanner.nextLine());
            Stock selected = stocks.get(input);

            if (action.equalsIgnoreCase("buy")) {
                double cost = qty * selected.price;
                if (cost > balance) {
                    System.out.println("Insufficient funds.");
                } else {
                    balance -= cost;
                    portfolio.put(input, portfolio.getOrDefault(input, 0) + qty);
                    System.out.println("Bought " + qty + " of " + input);
                }
            } else if (action.equalsIgnoreCase("sell")) {
                if (portfolio.getOrDefault(input, 0) < qty) {
                    System.out.println("Not enough shares.");
                } else {
                    balance += qty * selected.price;
                    portfolio.put(input, portfolio.get(input) - qty);
                    System.out.println("Sold " + qty + " of " + input);
                }
            }
        }
    }
}