import java.util.*;

public class StudentGradeTracker {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter number of students: ");
        int n = scanner.nextInt();
        int[] grades = new int[n];
        int sum = 0, max = Integer.MIN_VALUE, min = Integer.MAX_VALUE;

        for (int i = 0; i < n; i++) {
            System.out.print("Enter grade for student " + (i + 1) + ": ");
            grades[i] = scanner.nextInt();
            sum += grades[i];
            if (grades[i] > max) max = grades[i];
            if (grades[i] < min) min = grades[i];
        }

        System.out.println("\nSummary Report:");
        System.out.println("Average Grade: " + (sum / n));
        System.out.println("Highest Grade: " + max);
        System.out.println("Lowest Grade: " + min);
    }
}