
import serial
import matplotlib.pyplot as plt
from time import sleep

ser = serial.Serial('COM3', 9600)  # Replace COM3 with your port
x = []
y = []

plt.ion()
fig, ax = plt.subplots()
line, = ax.plot(x, y)

for i in range(100):
    data = ser.readline().decode().strip()
    try:
        temp = float(data)
        x.append(i)
        y.append(temp)
        line.set_xdata(x)
        line.set_ydata(y)
        ax.relim()
        ax.autoscale_view()
        plt.draw()
        plt.pause(0.1)
    except:
        continue

ser.close()
