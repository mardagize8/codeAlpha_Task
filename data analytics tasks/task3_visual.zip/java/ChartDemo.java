
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;
import javax.swing.*;

public class ChartDemo extends JFrame {
    public ChartDemo() {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.addValue(10, "Views", "Mon");
        dataset.addValue(15, "Views", "Tue");
        dataset.addValue(5, "Views", "Wed");

        JFreeChart chart = ChartFactory.createBarChart("Weekly Views", "Day", "Count", dataset,
                PlotOrientation.VERTICAL, false, true, false);

        ChartPanel panel = new ChartPanel(chart);
        setContentPane(panel);
    }

    public static void main(String[] args) {
        ChartDemo demo = new ChartDemo();
        demo.setSize(800, 600);
        demo.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        demo.setVisible(true);
    }
}
