
import java.io.*;
import java.util.*;

public class EDAReader {
    public static void main(String[] args) throws Exception {
        BufferedReader reader = new BufferedReader(new FileReader("data.csv"));
        String line;
        int rowCount = 0, colCount = 0;

        while ((line = reader.readLine()) != null) {
            String[] columns = line.split(",");
            colCount = columns.length;
            rowCount++;
        }
        reader.close();
        System.out.println("Rows: " + rowCount + ", Columns: " + colCount);
    }
}
