
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
using namespace std;

int main() {
    ifstream file("data.csv");
    string line, cell;
    vector<vector<string>> data;

    while (getline(file, line)) {
        stringstream ss(line);
        vector<string> row;
        while (getline(ss, cell, ',')) {
            row.push_back(cell);
        }
        data.push_back(row);
    }

    cout << "Rows: " << data.size() << ", Columns: " << (data.empty() ? 0 : data[0].size()) << endl;
    return 0;
}
