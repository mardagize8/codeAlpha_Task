
#include <iostream>
#include <string>
using namespace std;

int main() {
    string text;
    cout << "Enter a sentence: ";
    getline(cin, text);
    if (text.find("good") != string::npos) cout << "Positive\n";
    else if (text.find("bad") != string::npos) cout << "Negative\n";
    else cout << "Neutral\n";
    return 0;
}
