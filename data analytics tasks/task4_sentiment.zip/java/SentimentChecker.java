
import java.util.Scanner;

public class SentimentChecker {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter a sentence:");
        String text = scanner.nextLine();

        if (text.contains("good")) System.out.println("Positive");
        else if (text.contains("bad")) System.out.println("Negative");
        else System.out.println("Neutral");
    }
}
