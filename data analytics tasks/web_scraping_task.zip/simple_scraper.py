
import requests
from bs4 import BeautifulSoup

# Target URL
url = "https://example.com"

# Send HTTP request to the URL
response = requests.get(url)
if response.status_code == 200:
    soup = BeautifulSoup(response.text, "html.parser")

    # Extract all the headings (h1 tags)
    headings = soup.find_all("h1")
    for i, heading in enumerate(headings, 1):
        print(f"H1 Heading {i}: {heading.text.strip()}")
else:
    print("Failed to retrieve the webpage")
