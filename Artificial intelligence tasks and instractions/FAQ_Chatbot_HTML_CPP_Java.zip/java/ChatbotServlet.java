import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;

public class ChatbotServlet extends HttpServlet {

    private static final Map<String, String> faqMap = new HashMap<>();

    @Override
    public void init() {
        faqMap.put("what is your name", "I am a chatbot.");
        faqMap.put("how can I reset my password", "You can reset it from the login page.");
        faqMap.put("where is your office", "Our office is in Addis Ababa.");
    }

    private String preprocess(String text) {
        return text.toLowerCase().replaceAll("[^a-zA-Z0-9 ]", "").trim();
    }

    private String findBestMatch(String userQuestion) {
        userQuestion = preprocess(userQuestion);
        int maxScore = -1;
        String bestAnswer = "Sorry, I don't understand.";

        for (String q : faqMap.keySet()) {
            int score = similarity(preprocess(q), userQuestion);
            if (score > maxScore) {
                maxScore = score;
                bestAnswer = faqMap.get(q);
            }
        }
        return bestAnswer;
    }

    private int similarity(String s1, String s2) {
        Set<String> set1 = new HashSet<>(Arrays.asList(s1.split(" ")));
        Set<String> set2 = new HashSet<>(Arrays.asList(s2.split(" ")));
        set1.retainAll(set2);
        return set1.size();
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        String question = req.getParameter("question");
        String answer = findBestMatch(question);
        resp.setContentType("text/plain");
        resp.getWriter().write(answer);
    }
}
