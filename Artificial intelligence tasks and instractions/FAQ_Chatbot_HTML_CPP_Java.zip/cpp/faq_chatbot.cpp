#include <iostream>
#include <map>
#include <algorithm>
using namespace std;

string toLower(string s) {
    transform(s.begin(), s.end(), s.begin(), ::tolower);
    return s;
}

int main() {
    map<string, string> faqs = {
        {"what is your name", "I am a chatbot."},
        {"how can i reset my password", "Reset it from the login page."},
        {"where is your office", "Our office is in Addis Ababa."}
    };

    string userInput;
    cout << "Ask a question: ";
    getline(cin, userInput);

    userInput = toLower(userInput);
    bool found = false;

    for (auto& pair : faqs) {
        if (userInput.find(pair.first) != string::npos) {
            cout << pair.second << endl;
            found = true;
            break;
        }
    }

    if (!found) cout << "Sorry, I don't understand." << endl;

    return 0;
}
