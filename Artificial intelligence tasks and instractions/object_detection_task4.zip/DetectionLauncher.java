import java.io.*;

public class DetectionLauncher {
    public static void main(String[] args) {
        try {
            Process process = Runtime.getRuntime().exec("object_detector.exe");
            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            String line;
            while((line = reader.readLine()) != null) {
                System.out.println("Output: " + line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
