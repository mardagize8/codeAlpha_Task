#include <opencv2/opencv.hpp>
#include <opencv2/dnn.hpp>
using namespace cv;
using namespace dnn;

int main() {
    VideoCapture cap(0);
    if (!cap.isOpened()) return -1;

    Net net = readNet("yolov3.weights", "yolov3.cfg");
    net.setPreferableBackend(DNN_BACKEND_OPENCV);
    net.setPreferableTarget(DNN_TARGET_CPU);

    std::vector<std::string> classNames;
    std::ifstream ifs("coco.names");
    std::string line;
    while (getline(ifs, line)) classNames.push_back(line);

    Mat frame;
    while (cap.read(frame)) {
        Mat blob;
        blobFromImage(frame, blob, 1/255.0, Size(416, 416), Scalar(), true, false);
        net.setInput(blob);
        std::vector<Mat> outputs;
        net.forward(outputs, net.getUnconnectedOutLayersNames());

        for (auto& output : outputs) {
            for (int i = 0; i < output.rows; ++i) {
                float confidence = output.at<float>(i, 4);
                if (confidence > 0.5) {
                    int classId = max_element(output.ptr<float>(i) + 5, output.ptr<float>(i) + output.cols) - (output.ptr<float>(i) + 5);
                    int cx = (int)(output.at<float>(i, 0) * frame.cols);
                    int cy = (int)(output.at<float>(i, 1) * frame.rows);
                    int w  = (int)(output.at<float>(i, 2) * frame.cols);
                    int h  = (int)(output.at<float>(i, 3) * frame.rows);
                    rectangle(frame, Rect(cx - w/2, cy - h/2, w, h), Scalar(0, 255, 0), 2);
                    putText(frame, classNames[classId], Point(cx, cy - 10), FONT_HERSHEY_SIMPLEX, 0.5, Scalar(255, 0, 0));
                }
            }
        }

        imshow("YOLO Detection", frame);
        if (waitKey(1) == 27) break;
    }
    return 0;
}
