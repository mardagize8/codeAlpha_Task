#include <iostream>
#include <map>
using namespace std;

int main() {
    map<string, string> engToAmh = {
        {"hello", "selam"},
        {"world", "alem"},
        {"good", "tiru"},
        {"morning", "qen"}
    };

    string input;
    cout << "Enter a word (English): ";
    cin >> input;

    if (engToAmh.find(input) != engToAmh.end()) {
        cout << "Amharic: " << engToAmh[input] << endl;
    } else {
        cout << "Translation not found." << endl;
    }

    return 0;
}
