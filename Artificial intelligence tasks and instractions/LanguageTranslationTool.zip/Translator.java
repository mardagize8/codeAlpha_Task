import java.io.*;
import java.net.*;
import javax.net.ssl.HttpsURLConnection;

public class Translator {
    public static void main(String[] args) throws IOException {
        String text = "Hello";
        String sourceLang = "en";
        String targetLang = "fr";

        String urlStr = "https://libretranslate.com/translate";
        URL url = new URL(urlStr);
        HttpsURLConnection conn = (HttpsURLConnection) url.openConnection();

        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setDoOutput(true);

        String jsonInput = String.format("{\"q\":\"%s\",\"source\":\"%s\",\"target\":\"%s\",\"format\":\"text\"}", text, sourceLang, targetLang);
        try (OutputStream os = conn.getOutputStream()) {
            byte[] input = jsonInput.getBytes("utf-8");
            os.write(input, 0, input.length);
        }

        String response = "";
        try (BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "utf-8"))) {
            StringBuilder responseBuilder = new StringBuilder();
            String responseLine;
            while ((responseLine = br.readLine()) != null) {
                responseBuilder.append(responseLine.trim());
            }
            response = responseBuilder.toString();
        }

        System.out.println("Translated response: " + response);
    }
}
