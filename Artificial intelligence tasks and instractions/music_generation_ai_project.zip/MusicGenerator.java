
import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;

public class MusicGenerator {
    public static void main(String[] args) {
        String[] notes = { "C", "D", "E", "F", "G", "A", "B" };
        Random rand = new Random();

        try (FileWriter writer = new FileWriter("note_sequence.txt")) {
            for (int i = 0; i < 20; i++) {
                String note = notes[rand.nextInt(notes.length)];
                writer.write(note + " ");
            }
            System.out.println("Note sequence generated.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
