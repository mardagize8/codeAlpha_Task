
#include <iostream>
#include <fstream>
#include <string>

int main() {
    std::ifstream input("note_sequence.txt");
    std::ofstream output("generated_music.txt"); // placeholder for MIDI

    if (!input || !output) {
        std::cerr << "Error opening files." << std::endl;
        return 1;
    }

    std::string note;
    while (input >> note) {
        output << "MIDI_" << note << " ";
    }

    std::cout << "Converted note sequence to simulated MIDI format." << std::endl;

    input.close();
    output.close();
    return 0;
}
