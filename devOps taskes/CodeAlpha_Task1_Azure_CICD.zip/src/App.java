public class App {
    public static void main(String[] args) {
        System.out.println("✅ Java App Running for Azure CI/CD Test!");
    }
}
