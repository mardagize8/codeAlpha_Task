#include <iostream>
int main() {
    std::cout << "Hello from C++ Demo File!" << std::endl;
    return 0;
}
