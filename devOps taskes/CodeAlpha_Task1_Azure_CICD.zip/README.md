# CodeAlpha DevOps Task 1 – Azure CI/CD

## ✅ Technologies
- Java (Backend)
- HTML (Frontend)
- Azure Pipelines (CI/CD)
- C++ (Demo Purpose)

## 🚀 How to Run CI/CD
1. Push this project to a GitHub repo.
2. Go to Azure DevOps → Pipelines → Create New Pipeline.
3. Connect your GitHub repo.
4. Select `azure-pipelines.yml`.
5. Run the pipeline – Java code compiles automatically.

## 📦 Output
- Azure CI/CD compiles your Java project
- HTML and C++ files are included in the build artifacts
