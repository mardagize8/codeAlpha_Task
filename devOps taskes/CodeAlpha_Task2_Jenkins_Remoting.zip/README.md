# CodeAlpha DevOps Task 2 – Jenkins Remoting

## 🔧 Setup Instructions

1. Set up Jenkins locally or on cloud (e.g., localhost:8080).
2. Create a remote node:
   - Use SSH or VM
   - Copy and run `agent_setup.sh` on the agent machine.
3. Add node in Jenkins dashboard: Name = `remote-agent`.
4. Create a new pipeline project and use `Jenkinsfile` from this repo.
5. Trigger the build – all jobs run remotely.

## ✅ Components
- Java app (compiled remotely)
- C++ app (optional step)
- HTML frontend listing

## 🔐 Security Note
- Always secure agents with secret keys and firewall rules.
