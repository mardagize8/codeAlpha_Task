#!/bin/bash
# Run this on your remote node (Linux)

JENKINS_URL="http://<your_jenkins_server>:8080"
AGENT_NAME="remote-agent"
AGENT_WORKDIR="/home/jenkins/agent"
JAR_FILE="agent.jar"
SECRET="<copy-from-jenkins>"

wget $JENKINS_URL/jnlpJars/$JAR_FILE
java -jar $JAR_FILE -jnlpUrl $JENKINS_URL/computer/$AGENT_NAME/jenkins-agent.jnlp -secret $SECRET -workDir $AGENT_WORKDIR
