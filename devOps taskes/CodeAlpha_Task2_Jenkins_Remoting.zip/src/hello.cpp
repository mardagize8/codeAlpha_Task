#include <iostream>
int main() {
    std::cout << "Running C++ job on Jenkins Agent!" << std::endl;
    return 0;
}
