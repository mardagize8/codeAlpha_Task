public class App {
    public static void main(String[] args) {
        System.out.println("✅ Running Java job on Jenkins Agent!");
    }
}
