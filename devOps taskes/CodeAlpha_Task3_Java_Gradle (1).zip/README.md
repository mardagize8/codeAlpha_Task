# CodeAlpha DevOps Task 3 – Java with Gradle

## 🛠 Technologies
- Java
- Gradle
- Optional: HTML & C++

## 🚀 Build Instructions
1. Make sure Gradle is installed.
2. Run `gradle build` to compile the app.
3. Run `gradle runApp` to execute `App.java`.

## 💡 Optional Extensions
- Integrate GitHub Actions or Jenkins for CI/CD
- Package as JAR with `gradle jar`
- Include HTML/C++ files in build archive

## 📂 Directory
- Java: `src/main/java/App.java`
- UI: `web/index.html`
- C++: `cpp/demo.cpp`
