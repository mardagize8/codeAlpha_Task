#include <iostream>
int main() {
    std::cout << "C++ snippet for Gradle project!" << std::endl;
    return 0;
}
