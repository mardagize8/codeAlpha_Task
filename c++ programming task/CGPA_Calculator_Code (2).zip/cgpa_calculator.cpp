#include <iostream>
using namespace std;

int main() {
    int n;
    double grade, credit, totalGradePoints = 0, totalCredits = 0;

    cout << "Enter number of courses: ";
    cin >> n;

    for (int i = 0; i < n; i++) {
        cout << "Enter grade for course " << i + 1 << ": ";
        cin >> grade;
        cout << "Enter credit hours for course " << i + 1 << ": ";
        cin >> credit;
        totalGradePoints += grade * credit;
        totalCredits += credit;
    }

    double cgpa = totalGradePoints / totalCredits;
    cout << "Your CGPA is: " << cgpa << endl;

    return 0;
}