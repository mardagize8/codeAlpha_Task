import java.util.Scanner;

public class CGPACalculator {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter number of courses: ");
        int n = input.nextInt();
        double totalGradePoints = 0, totalCredits = 0;

        for (int i = 0; i < n; i++) {
            System.out.print("Enter grade for course " + (i + 1) + ": ");
            double grade = input.nextDouble();
            System.out.print("Enter credit hours for course " + (i + 1) + ": ");
            double credit = input.nextDouble();
            totalGradePoints += grade * credit;
            totalCredits += credit;
        }

        double gpa = totalGradePoints / totalCredits;
        System.out.printf("Your CGPA is: %.2f\n", gpa);
    }
}