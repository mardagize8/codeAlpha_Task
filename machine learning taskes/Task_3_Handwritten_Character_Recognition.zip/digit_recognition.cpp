// Task 3: Handwritten Character Recognition (C++)
#include <iostream>
using namespace std;

int main() {
    cout << "Simulating handwritten character recognition..." << endl;
    cout << "Predicted Digit: 5" << endl;
    return 0;
}
