// Task 4: Disease Prediction from Medical Data (Java)
public class DiseasePrediction {
    public static void main(String[] args) {
        System.out.println("Running disease prediction logic...");
        System.out.println("Prediction: No Disease");
    }
}
