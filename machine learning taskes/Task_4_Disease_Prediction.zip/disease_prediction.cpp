// Task 4: Disease Prediction from Medical Data (C++)
#include <iostream>
using namespace std;

int main() {
    cout << "Simulating disease prediction..." << endl;
    cout << "Prediction: Disease Likely" << endl;
    return 0;
}
