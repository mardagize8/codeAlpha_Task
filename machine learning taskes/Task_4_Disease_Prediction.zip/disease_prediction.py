# Task 4: Disease Prediction from Medical Data (Python)
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score

# Sample dataset (simulate)
data = pd.DataFrame({
    'age': [25, 45, 52, 36, 23],
    'bp': [120, 140, 130, 110, 125],
    'cholesterol': [200, 240, 180, 190, 220],
    'diabetes': [1, 0, 1, 0, 1]
})
X = data[['age', 'bp', 'cholesterol']]
y = data['diabetes']

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)

model = RandomForestClassifier()
model.fit(X_train, y_train)
predictions = model.predict(X_test)
print("Accuracy:", accuracy_score(y_test, predictions))
