// Task 2: Emotion Recognition from Speech (C++)
#include <iostream>
using namespace std;

int main() {
    cout << "Simulating speech emotion recognition..." << endl;
    cout << "Predicted Emotion: Happy" << endl;
    return 0;
}
