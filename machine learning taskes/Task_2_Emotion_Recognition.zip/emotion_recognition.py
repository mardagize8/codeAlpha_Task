# Task 2: Emotion Recognition from Speech (Python)
import librosa
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier

# Example: Extract MFCCs from an audio file
def extract_features(file_path):
    audio, sr = librosa.load(file_path)
    mfccs = librosa.feature.mfcc(y=audio, sr=sr, n_mfcc=40)
    return np.mean(mfccs.T, axis=0)

# Dummy training
X = [np.random.rand(40) for _ in range(100)]
y = np.random.choice(['happy', 'sad', 'angry'], 100)

model = RandomForestClassifier()
model.fit(X, y)
print("Model trained on dummy data.")
