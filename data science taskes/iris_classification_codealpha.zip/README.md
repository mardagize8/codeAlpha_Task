# CodeAlpha_IrisClassification

## 🌸 Project: Iris Flower Classification

This project is part of the **CodeAlpha Data Science Internship**. It uses machine learning to classify iris flowers into three species: Setosa, Versicolor, and Virginica based on their petal and sepal measurements.

---

## ✅ Objectives

- Load and understand the Iris dataset
- Train a classification model using Scikit-learn
- Evaluate the model’s accuracy
- Visualize feature distributions

---

## ⚙️ Tools & Libraries Used

- Python
- Pandas
- Scikit-learn
- Seaborn
- Matplotlib

---

## 📊 Output Highlights

- Accuracy Score
- Classification Report
- Pair Plot Visualization

---

## 🚀 How to Run

```bash
python iris_classification.py
```

---

## 🔗 Dataset Reference

- [Iris Dataset on Kaggle](https://www.kaggle.com/datasets/saurabh00007/iriscsv)

---

## 👩‍💻 Author

Melat — CodeAlpha Intern
