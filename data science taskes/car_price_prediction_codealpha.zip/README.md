# CodeAlpha_CarPricePrediction

## 🚗 Project: Car Price Prediction

This project is part of the **CodeAlpha Data Science Internship**. It uses machine learning to predict used car prices based on factors such as year, mileage, fuel type, etc.

---

## ✅ Objectives

- Preprocess and clean car dataset
- Encode categorical features
- Train linear regression model
- Visualize prediction accuracy

---

## ⚙️ Tools & Libraries Used

- Python
- Pandas
- Scikit-learn
- Matplotlib
- Seaborn

---

## 📊 Output Highlights

- R² Score
- Mean Squared Error
- Scatter plot of actual vs predicted prices

---

## 🚀 How to Run

1. Download dataset from:
   [Car Price Dataset](https://www.kaggle.com/datasets/vijayaadithyanvg/car-price-predictionused-cars)
2. Save as `car data.csv`
3. Run the script:
```bash
python car_price_prediction.py
```

---

## 👩‍💻 Author

Melat — CodeAlpha Intern
