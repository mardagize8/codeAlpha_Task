// CarPricePrediction.java
public class CarPricePrediction {
    public static void main(String[] args) {
        System.out.println("Use Python for car price ML regression.");
    }
}
