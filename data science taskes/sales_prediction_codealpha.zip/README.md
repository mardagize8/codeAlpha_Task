# CodeAlpha_SalesPrediction

## 📈 Project: Sales Prediction using Regression

This project is part of the **CodeAlpha Data Science Internship**. It predicts product sales based on advertising spend across TV, radio, and newspaper using linear regression.

---

## ✅ Objectives

- Analyze impact of ad spend on sales
- Train regression model
- Evaluate accuracy and visualize predictions

---

## ⚙️ Tools & Libraries Used

- Python
- Pandas
- Scikit-learn
- Matplotlib
- Seaborn

---

## 📊 Output Highlights

- R² Score
- MSE (Mean Squared Error)
- Scatter Plot (Predicted vs Actual Sales)

---

## 🚀 How to Run

1. Download dataset from:
   [Sales Dataset](https://www.kaggle.com/datasets/bumba5341/advertisingcsv)
2. Save as `advertising.csv`
3. Run the script:
```bash
python sales_prediction.py
```

---

## 👩‍💻 Author

Melat — CodeAlpha Intern
