// sales_prediction.cpp
#include <iostream>
int main() {
    std::cout << "Use Python for sales prediction with ML." << std::endl;
    return 0;
}
