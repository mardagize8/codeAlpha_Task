// SalesPrediction.java
public class SalesPrediction {
    public static void main(String[] args) {
        System.out.println("Use Python for sales prediction using regression.");
    }
}
