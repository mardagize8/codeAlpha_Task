# CodeAlpha_UnemploymentAnalysis

## 📈 Project: Unemployment Analysis in India

This project explores India's unemployment trends using visualization and time-series techniques as part of the **CodeAlpha Data Science Internship**.

---

## ✅ Objectives

- Clean and process unemployment data
- Visualize regional and temporal trends
- Use heatmaps, bar plots, and line charts for insights
- Analyze impact of time and region on unemployment

---

## ⚙️ Tools & Libraries Used

- Python
- Pandas
- Matplotlib
- Seaborn

---

## 📊 Output Highlights

- State-wise bar chart of unemployment rates
- Monthly average unemployment trends
- Heatmap: State vs Month analysis

---

## 🚀 How to Run

1. Download the dataset from Kaggle:
   [Unemployment Dataset](https://www.kaggle.com/datasets/gokulrajkmv/unemployment-in-india)
2. Save it as `Unemployment in India.csv` in the script directory.
3. Run the script:
```bash
python unemployment_analysis.py
```

---

## 👩‍💻 Author

Melat — CodeAlpha Intern
