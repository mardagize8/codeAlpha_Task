# unemployment_analysis.py

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

df = pd.read_csv("Unemployment in India.csv")
print("Initial Data:")
print(df.head())

df.columns = [col.strip().replace(" ", "_").lower() for col in df.columns]
df.rename(columns={'estimated_unemployment_rate%': 'unemployment_rate'}, inplace=True)

print("\nData Info:")
print(df.info())

print("\nSummary Stats:")
print(df.describe())

plt.figure(figsize=(12, 6))
sns.barplot(x='unemployment_rate', y='region', data=df.sort_values(by='unemployment_rate', ascending=False))
plt.title("Unemployment Rate by State")
plt.xlabel("Rate (%)")
plt.ylabel("State")
plt.tight_layout()
plt.show()

plt.figure(figsize=(14, 6))
df['date'] = pd.to_datetime(df['date'])
monthly_avg = df.groupby(df['date'].dt.to_period('M'))['unemployment_rate'].mean()
monthly_avg.plot(marker='o', linestyle='-')
plt.title("Monthly Average Unemployment Rate")
plt.xlabel("Month")
plt.ylabel("Unemployment Rate (%)")
plt.grid(True)
plt.tight_layout()
plt.show()

pivot_df = df.pivot_table(values='unemployment_rate', index='region', columns=df['date'].dt.to_period('M'))
plt.figure(figsize=(14, 8))
sns.heatmap(pivot_df, cmap='coolwarm', linewidths=0.5)
plt.title("Unemployment Rate Heatmap (State vs Time)")
plt.xlabel("Month")
plt.ylabel("State")
plt.tight_layout()
plt.show()
