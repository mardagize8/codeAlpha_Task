
#include <iostream>
#include <string>
bool safeCopy(const char* src) {
    std::string input(src);
    if (input.length() > 1024) return false;
    // safe operations here
    return true;
}
int main() {
    const char* test = "example input";
    std::cout << (safeCopy(test) ? "Safe" : "Unsafe") << std::endl;
    return 0;
}
