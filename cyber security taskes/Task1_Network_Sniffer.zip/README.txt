Cyber Security Task 1: Basic Network Sniffer

How to Run:
-----------
1. Make sure you have Python installed (preferably Python 3.x).
2. Install the required library: scapy
   Run the following command in your terminal or command prompt:
       pip install scapy

3. Run the script with administrator/root privileges:
       sudo python3 network_sniffer.py  (Linux/Mac)
       OR
       Run Command Prompt as Administrator and run:
       python network_sniffer.py  (Windows)

Note:
- Press Ctrl+C to stop the sniffer.
- The script prints source/destination IP, protocol, port info, and partial payload.

Author: ChatGPT (OpenAI)
