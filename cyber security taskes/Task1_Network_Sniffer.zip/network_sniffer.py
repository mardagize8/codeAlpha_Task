from scapy.all import sniff
from scapy.layers.inet import IP, TCP, UDP

def packet_callback(packet):
    if IP in packet:
        ip_layer = packet[IP]
        print(f"\n[+] New Packet Captured")
        print(f"    Source IP     : {ip_layer.src}")
        print(f"    Destination IP: {ip_layer.dst}")
        print(f"    Protocol      : {ip_layer.proto}")

        if TCP in packet:
            print(f"    TCP Port      : {packet[TCP].sport} -> {packet[TCP].dport}")
        elif UDP in packet:
            print(f"    UDP Port      : {packet[UDP].sport} -> {packet[UDP].dport}")

        print(f"    Payload       : {bytes(packet[IP].payload)[:50]}")

# Start sniffing (requires root/admin privileges)
print("[*] Starting packet sniffer...")
sniff(filter="ip", prn=packet_callback, store=False)
