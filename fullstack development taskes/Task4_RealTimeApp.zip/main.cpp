// Task4_RealTimeApp - C++ File
#include <iostream>
int main() { std::cout << "Task4_RealTimeApp"; return 0; }