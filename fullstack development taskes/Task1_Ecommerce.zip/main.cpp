// Task1_Ecommerce - C++ File
#include <iostream>
int main() { std::cout << "Task1_Ecommerce"; return 0; }