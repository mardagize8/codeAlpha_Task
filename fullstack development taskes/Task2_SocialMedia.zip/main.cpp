// Task2_SocialMedia - C++ File
#include <iostream>
int main() { std::cout << "Task2_SocialMedia"; return 0; }