Task 2: UI/UX Design
Use Figma, Adobe XD, Sketch, or InVision to design web and mobile UI.
Include wireframes, mockups, and prototypes.