Task 1: Logo Redesign
Use Illustrator, CorelDRAW, Figma, or Canva to redesign the existing logo.
Include multiple versions and design logic.