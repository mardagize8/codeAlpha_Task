Task 3: Typography Practice
Use Illustrator, Photoshop, or Canva to create typography-based visuals.
Focus on font pairing, spacing, and visual impact.