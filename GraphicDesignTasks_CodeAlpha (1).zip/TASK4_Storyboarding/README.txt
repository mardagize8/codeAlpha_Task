Task 4: Storyboarding Design
Use Storyboard That, Illustrator, Photoshop, or Procreate to create visual narratives.
Include storyboard panels and frame descriptions.